package com.Darkinho11.Farmacia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FarmaciaApplicationTests {

	@Test
	void contextLoads() {
	}

}
